import LoP from "../../test/pages/login.page.js";
import Logout from "../../test/pages/logout.page.js";

describe("login and logout from the page", async()=>{

    it("Valid Login Test", async()=>{
        await LoP.url()
        await LoP.header("Login Page")
        await LoP.enterUsername('tomsmith')
        await LoP.usernameFocused()
        await LoP.enterPassword("SuperSecretPassword!")
        await LoP.passwordFocused()
        await LoP.checkTheButtonNamedLogin("Login");
        await LoP.clickLogin()
        await LoP.checkMessage("You logged into a secure area!")
        await expect(browser).toHaveUrl("https://the-internet.herokuapp.com/secure")
        await Logout.checkLogoutHeader("Secure Area")
        await LoP.checkfooter("Elemental Selenium")
        await Logout.checkLogout();
        await Logout.checkSuccessLogout("You logged out of the secure area!")
        await expect(browser).toHaveUrl("https://the-internet.herokuapp.com/login")

    })



    it("Invalid username and password", async()=>{
        await LoP.url()
        await LoP.enterUsername('invalidusername')
        await LoP.enterPassword("SuperSecretPassword")
        await LoP.clickLogin();
        await LoP.wrongLogin("Your username is invalid!")
    })



    it("Only login click", async()=>{        
        await LoP.url()
        await LoP.clickLogin();
        await LoP.wrongLogin("Your username is invalid!")
    })



it("Invalid username and valid password", async()=>{
        await LoP.url()
        await LoP.enterUsername('hi')
        await LoP.enterPassword("SuperSecretPassword!")
        await LoP.clickLogin();
        await LoP.wrongLogin("Your username is invalid!")
    })



    it("Valid username and Invalid password", async()=>{
        await LoP.url()
        await LoP.enterUsername('tomsmith')
        await LoP.enterPassword("SuperSecretPassword")
        await LoP.clickLogin();
        await LoP.wrongLogin("Your password is invalid!")
    })



})