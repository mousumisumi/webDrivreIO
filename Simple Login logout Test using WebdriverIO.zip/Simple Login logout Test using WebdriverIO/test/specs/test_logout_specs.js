
import Logout from "../../test/pages/logout.page.js";
describe("login and logout from the page", async()=>{

    it("inValid Logout Test", async()=>{
        await Logout.checkInvalidLogout()
        await browser.closeWindow()
        // await LoP.header("Login Page")
        // await LoP.checkTheButtonNamedLogin("Login");
        // await LoP.clickLogin()
        // await LoP.checkMessage("You logged into a secure area!")
        // await expect(browser).toHaveUrl("https://the-internet.herokuapp.com/secure")


    })

    // it("Invalidusername Login Test", async()=>{

    //     await browser.url("https://the-internet.herokuapp.com/login")
    //     await browser.pause(3000)
    //     await LoP.enterUsername('invalidusername')
    //     await browser.pause(3000)
    //     await LoP.enterPassword("SuperSecretPassword")
    //     await browser.pause(3000)
    //     await LoP.clickLogin();
    //     await browser.pause(3000)
    //     await LoP.wrongLogin("Your username is invalid!")

    // })

    // it("Type username", async()=>{

    //     await $("#username").setValue("tomsmith")

    // })

    // it ("Type password", async()=>{
    //     await $("#password").setValue("SuperSecretPassword!")

    // })

    // it ("Click on Login Button", async()=>{
    //     await $("button[type='submit']").click()
    // })

    // it ("Successful Login", async()=>{
    //     await expect($("#flash")).toHaveTextContaining('You logged into a secure area!')
    // })



})