class logout{

    get outheader(){
        return $("//h2[text()=' Secure Area']")
    }

    get log_out(){
        return $("//i[@class='icon-2x icon-signout']")
    }
    get successLogout(){
        return $("#flash")
    }

    async checkLogoutHeader(msg){
        await expect(this.outheader).toHaveText(msg)

    }

    async checkLogout(){
        await this.log_out.click()
    }

    async checkSuccessLogout(msg){
        await expect(this.successLogout).toHaveTextContaining(msg)
    }

    async checkInvalidLogout(){
        
        await browser.url("https://the-internet.herokuapp.com/secure")
    }
}

export default new logout()