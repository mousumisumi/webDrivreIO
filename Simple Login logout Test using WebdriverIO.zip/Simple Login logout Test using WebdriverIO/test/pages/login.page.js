class LoginPage{
    //url
    async url(){
        await browser.url("https://the-internet.herokuapp.com/login")
    }

    // Login Header 
    get title(){
        return $("//h2")
    }
    async header(name){
        await expect(this.title).toHaveText(name)
    }


    // username Text Box
    get usernameTextbox(){
        return $("#username")
    }
    async usernameFocused(){
        await expect(this.usernameTextbox).toBeFocused()
    }
    async enterUsername(username){
        await this.usernameTextbox.setValue(username)
    }


    // password Text Box
    get passwordTextbox(){
        return $("#password")
    }
    async passwordFocused(){
        await expect(this.passwordTextbox).toBeFocused();
    }
    async enterPassword(password){
        await this.passwordTextbox.setValue(password)
    }


    // Login
    get loginButton(){
        return $("button[type='submit']")
    }
    get invalidLogin(){
        return $("#flash")
    }
    async checkTheButtonNamedLogin(msg){
        await expect(this.loginButton).toHaveTextContaining(msg)
    }
    async clickLogin(){
        await this.loginButton.click()
    }
    async wrongLogin(msg){
        await expect(this.invalidLogin).toHaveTextContaining(msg)
    }


    
    // Footer
    get footer(){
        return $("//a[@href='http://elementalselenium.com/']")
    }
    async checkfooter(msg){
        await expect(this.footer).toHaveText(msg)
    }


    // After Login activity
    get loginMessage(){
        return $("#flash")
    }
    async checkMessage(msg){
        await expect(this.loginMessage).toHaveTextContaining(msg)
    }
    async wrongLogin(msg){
        await expect(this.invalidLogin).toHaveTextContaining(msg)
    }

}

export default new LoginPage()