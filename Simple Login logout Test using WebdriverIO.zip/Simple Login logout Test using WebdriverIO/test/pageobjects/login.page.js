class LoginPage{

    get usernameTextbox(){
        return $("#username")
    }

    get passwordTextbox(){
        return $("#password")
    }

    get loginButton(){
        return $("button[type='submit']")
    }

    get loginMessage(){
        return $("#flash")
    }

    async enterUsername(username){
        await this.usernameTextbox.setValue()
    }

    async enterPassword(password){

        await this.usernameTextbox.setValue()
    }

    async clickLogin(){
        await this.loginButton.click()
    }

    async checkMessage(msg){
        await expect(this.loginMessage).toHaveTextContaining(msg)
    }
}

export default new LoginPage()